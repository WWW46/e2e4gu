
let x= 0;

function validate(){
    let form = document.getElementsByClassName("indicator");
    let email = document.getElementById("emailsignup").value;
    let pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/
    if(email.match(pattern))
    {
        form[0].textContent = 'Введён правильный емайл';
        x+=1;
        return x
    }
    else{
        form[0].textContent = 'Введён неправильный емайл';
        x-=1;
    }
    if (email == "") {
        form[0].textContent = 'Введите емайл';
    }
}

function nameFunction(){
    let form = document.getElementsByClassName("name");
    let email = document.getElementById("usernamesignup").value;
    let pattern = "[A-Za-zА-Яа-яЁё]{3,}"

    //Индиец по фамилии Брахматра носит самое длинное имя в мире. Оно состоит из 1478 букв.
    if(email.match(pattern) && email.length<1478)
    {
        form[0].textContent = 'Введено правильное имя';
        x+=1;
        return x;
    }
    else{
        form[0].textContent = 'Введено неправильное имя';
        x-=1;
    }
    if (email == "") {
        form[0].textContent = 'Введите имя';
    }
}

function lastNameFunction(){
    let form = document.getElementsByClassName("lastname");
    let email = document.getElementById("usernamesignup1").value;
    let pattern = "[A-Za-zА-Яа-яЁё]{3,}"
    //Названа самая длинная фамилия в мире.Фамилия 45-летнего плиточника из Рейнской области Бернда Оттовордемгентшенфельда в немецком написании состоит из 24 букв.
    if(email.match(pattern) && email.length<24)
    {
        form[0].textContent = 'Введена правильная фамилия';
        x+=1;
    }
    else{
        form[0].textContent = 'Введена неправильная фамилия';
        x-=1;
    }
    if (email == "") {
        form[0].textContent = 'Введите фамилию';
    }
}

function password(){
    let form = document.getElementsByClassName("pass");
    let email = document.getElementById("passwordsignup").value;
    let email2 = document.getElementById("passwordsignup2").value;
    let pattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ -/:-@\[-`{-~]).{6,64}$"
    if(email.match(pattern) && email == email2)
    {
        form[0].textContent = 'Введён правильный пароль';
        x+=1;
    }
    else{
        form[0].textContent = 'Введен неправильный пароль';
        x-=1;
    }
    if (email == "") {
        form[0].textContent = 'Введите пароль';
    }
}
let y =[]

document.getElementById("date").addEventListener("change", function() {
    var input = this.value;
    var dateEntered = new Date(input);
    console.log(input); //e.g. 2015-11-13
    let date1 = new Date();
    var diff = Math.abs(date1 - input);
    function diffDates(day_one, day_two) {
        return (day_one - day_two) / (60 * 60 * 24 * 1000);
    };
    
    for (let i = 0; i<= 3; i++){
        y[i] = input[i];
    }
    let g = document.getElementsByClassName('button24')
    let u = document.getElementsByClassName('div')
    console.log(y)
    var result = y.reduce((res, item) => res + item, '');
    console.log(result);
    if (2023 - result >= 18){
        u[0].innerHTML = '<a href="#" onclick="validateFunction()" class="button24">Зарегистрироваться!</a>'
    }else{
        g[0].remove();
    }
    
});
function validateFunction(){
    let email1 = document.getElementById("emailsignup").value;
    let pattern1 = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/
    let pattern2 = "[A-Za-zА-Яа-яЁё]{3,}"
    let email2 = document.getElementById("usernamesignup").value;
    let email3 = document.getElementById("usernamesignup1").value;
    let pattern3 = "[A-Za-zА-Яа-яЁё]{3,}"
    
    let email4 = document.getElementById("passwordsignup").value;
    let email5 = document.getElementById("passwordsignup2").value;
    let pattern4 = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ -/:-@\[-`{-~]).{6,64}$";
    if(email1.match(pattern1) &&email2.match(pattern2) && email2.length<1478  && email3.match(pattern3) && email3.length<24 && email4.match(pattern4) && email4 == email5){
        alert('Вы успешно зарегестрировались !');
    }else{
        alert('Проверьте данные ввода еще раз ! Возможно вы допустили где-то ошибку !')
    }
}
